<template>
  <form @submit.prevent="handleSubmit">
    <div class="main" style="margin-left: 25%">
      <label for="userid" style="margin-left: 30%">Email</label>
      <input type="text" name="email" placeholder="email" v-model="email" />
      <br />
      <label for="password">Password</label>
      <input
        type="password"
        name="password"
        placeholder="password"
        v-model="password"
      />
      <button class="btn" @click="addUser()">Login</button>
    </div>
  </form>
</template>
<script>
import axios from "axios";
import setAuthHeader from "@/utils/setAuthHeader";

export default {
  name: "post_api",
  data() {
    return {
      email: "",
      password: "",
    };
  },
  methods: {
    addUser() {
      // let result =
      axios
        .post("https://dev.icc-health.com/dev/login", {
          email: this.email,
          password: this.password,
        })
        .then((response) => {
          localStorage.setItem("User-Data", response.data.token);
          setAuthHeader(response.data.token);
          this.$router.push({ name: "te-st" });
        });
    },
  },
};
</script>
<style>
body{
  margin: 8%;
  background-image: url("@/assets/2314983.webp" ) ;
  background-repeat: no-repeat;
  background-size: cover;
}
h1 {
  color: #fff;
}
.main {
  border-radius: 20px;
  position: relative;
  margin-left: 30%;
  width: 30%;
  background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
}

label {
  position: relative;
  margin-top: 40px;
  margin-left: 10%;
  color: #fff;
  font-size: 2.5em;
  justify-content: center;
  font-weight: bold;
  
}

.btn {
  width: 100%;
  height: 50px;
  margin-top: 20px;
  margin-left: 30%;
  color: #fff;
  background: #573b8a;
  font-size: 1em;
  font-weight: bold;
}

</style>
