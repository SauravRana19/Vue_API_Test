<template>
  <div>
    <h1>User-Data</h1>
    <!-- <div> 
        <h1>{{ name }}</h1>
    </div> -->

    <!-- <h2 style="color: black">
          {{ post.data }}
        </h2> -->
    <table class="table">
      <table
        style="width: auto; height: auto; align-items: center; margin-left: 5%"
      >
        <tr>
          <th>email</th>
          <th>firstName</th>
          <th>genderName</th>
          <th>lastName</th>
          <th>address</th>
          <th>country</th>
          <th>fullName</th>
        </tr>
        <tr v-for="item in post.data" v-bind:key="item.id">
          <td>{{ item.email }}</td>
          <td>{{ item.firstName }}</td>
          <td>{{ item.genderName }}</td>
          <td>{{ item.lastName }}</td>
          <td>{{ item.address }}</td>
          <td>{{ item.country }}</td>
          <td>{{ item.fullName }}</td>
        </tr>
      </table>
    </table>
  </div>
</template>
<script>
import axios from "axios";

export default {
  name: "tes-t",
  //   components: {},
  data() {
    return {
      name: "h-lo",
      post: [],
    };
  },
  methods: {
    getdata() {
      axios.get("https://dev.icc-health.com/dev/patient").then((response) => {
        console.log(response.data);
        this.post = response.data;
      });
    },
  },
  mounted() {
    let vr = this.getdata();
    console.log(vr);
  },
};
</script>
<style>
th {
  padding: 10px;
  border: 1px solid black;
}

td {
  padding: 10px;
  border: 1px solid black;
  text-align: left;
}

tr:nth-child(even) {
  background-color: white;
}

tr:nth-child(odd) {
  background-color: #eee;
}
h1{
  text-align: center;
}
</style>
