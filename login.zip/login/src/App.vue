<template>
  <div>
    <RouterView />
  </div>
</template>

<script>
export default {
  name: "ext-ra",
  components: {},
};
</script>
<style></style>
